APK BUILD GUIDE (cloud build via GitHub Actions)
1. Upload this project folder to a GitHub repository (repository can be private).
2. Open repository > Actions > Build Prime Tech Systems APK.
3. Select Run workflow if available, then run.
4. When workflow succeeds, open the run, scroll to Artifacts, download PrimeTechSystems-debug-apk.
5. Extract artifact and install app-debug.apk on Android. Allow install from this source if Android prompts.

This ZIP is an Android project, not a prebuilt APK. This environment has no Android SDK/build tools to compile and verify an APK here.
