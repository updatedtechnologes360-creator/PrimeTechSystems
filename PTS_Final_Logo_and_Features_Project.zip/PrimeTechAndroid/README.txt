Prime Tech Systems Android project

Open this folder in Android Studio, allow Gradle sync, then Build > Build Bundle(s) / APK(s) > Build APK(s).
The generated APK will be located under app/build/outputs/apk/debug/app-debug.apk.

This project wraps the local HTML app in an Android WebView. Records use browser local storage and remain on the device.
No signed release APK has been built in this environment (Android SDK/Gradle are not installed here).
